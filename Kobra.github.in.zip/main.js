function myfunc() {
  var x = document.getElementById(1).value;
  var y = document.getElementById(2).value;
  if (x == kobra) {
    alert("OK");
  } else {
    alert("not ok");
  }
}
